package cPro;

public class Test {
	public void print()
	{
		System.out.println("c");
	}

}
