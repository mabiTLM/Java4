module modulepathTest2 {
	requires moduleTest2;
}