module bPro {
	requires transitive cPro;
	requires transitive dPro;
	exports bPro;
}