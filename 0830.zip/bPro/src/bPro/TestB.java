package bPro;

import cPro.Test;

public class TestB  {
	public void print() {
		Test c = new Test();
		c.print();
	}

}
