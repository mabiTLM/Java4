module aPro {
	requires bPro;
}