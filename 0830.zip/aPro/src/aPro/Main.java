package aPro;

import bPro.TestB;
import cPro.Test;
import dPro.TestD;

public class Main {
	public static void main(String[] args) 
	{
		TestB b = new TestB();
		b.print();
		
	}

}
