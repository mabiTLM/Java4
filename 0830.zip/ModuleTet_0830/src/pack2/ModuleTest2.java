package pack2;

public class ModuleTest2 {
	public void print() {
		System.out.println("ModuleTest2");
	}
}
