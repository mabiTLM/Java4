package pack1;

public class ModuleTest1 {
	public void print() {
		System.out.println("ModuleTest1");
	}
}
