package dPro;

public class TestD {
	public void print() {
		System.out.print("d");
	}

}
