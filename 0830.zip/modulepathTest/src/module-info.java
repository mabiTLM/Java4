module modulepathTest {
	requires moduleTest2;
}