package modulepathTest;

import pack3.ModuleTest3;
import pack4.ModuleTest4;

public class Main {
	
	public static void main(String[] args)
	{
		ModuleTest3 moduleTest1 = new ModuleTest3();
		moduleTest1.print();
		ModuleTest4 moduleTest2 = new ModuleTest4();
		moduleTest2.print();
	}

}
