package webClass_0829;

public non-sealed class YellowRace extends Person
{
	int [] skinColor;
	
	YellowRace()
	{
		super();
		skinColor = new int[] {235,235,235}; //
		String tempColor = "";
	}
}