package webClass_0829.calculator.study;

public interface MultiplyInterface 
{
	default int multiply(int num1, int num2)
	{
		return num1*num2;
	}
}
