package webClass_0829.calculator.study;

public interface DivideInterface
{
	default double divide(double num1, int num2)
	{
		return num1/num2;
	}
}
