package webClass_0829.calculator.study;

public interface remainInterface 
{
	default int remain(int num1, int num2)
	{
		return num1%num2;
	}
}
