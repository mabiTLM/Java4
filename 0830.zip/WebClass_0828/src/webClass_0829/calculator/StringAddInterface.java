package webClass_0829.calculator;

public interface StringAddInterface 
{
	
}
