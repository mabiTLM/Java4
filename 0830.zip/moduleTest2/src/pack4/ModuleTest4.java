package pack4;

public class ModuleTest4 
{
	public void print()
	{
		System.out.print("ModuleTest4");
	}
}
