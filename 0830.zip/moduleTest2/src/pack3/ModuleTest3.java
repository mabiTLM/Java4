package pack3;

//import pack4.ModuleTest4;

public class ModuleTest3 {// 
	public void print()
	{
		//ModuleTest4 a= new ModuleTest4();
		
		//a.print();

		System.out.print("ModuleTest3");
	}

}