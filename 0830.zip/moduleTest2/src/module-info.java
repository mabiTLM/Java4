module moduleTest2{
	exports pack3;
//	exports pack4;
}