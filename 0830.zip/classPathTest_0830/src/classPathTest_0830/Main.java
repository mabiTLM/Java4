package classPathTest_0830;

import pack1.ModuleTest1;
import pack2.ModuleTest2;

public class Main
{
	public static void main(String[] args)
	{
		ModuleTest1 moduleTest1 = new ModuleTest1();
		moduleTest1.print();
		ModuleTest2 moduleTest2 = new ModuleTest2();
		moduleTest2.print();
	}//푸쉬확인중
}