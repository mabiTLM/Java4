module modulepathTest3 
{
	requires moduleTest34; //프로젝트명 또는 파일명
}